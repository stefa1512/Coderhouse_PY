def suma(*args):
    resultado = 0
    for val in args:
        resultado += val
    return resultado

def multiplicar(num1: int, num2: int):
    return num1*num2

def dividir(num1: int, num2: int):
    return num1 / num2
