import json

nombre = "Stefano"

def tangente(num1):
    return num1


class Clase:
    pass
