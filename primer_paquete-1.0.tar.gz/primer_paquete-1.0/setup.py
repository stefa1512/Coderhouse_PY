from setuptools import setup

setup(
    name = "primer_paquete",
    version = "1.0",
    descripcion = "",
    author = "Stefano",
    author_email = "stefanluigi15@gmail.com",
    packages = ["calculadoras"]
)
