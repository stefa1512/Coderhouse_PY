from setuptools import setup

setup(
    name = "Segundo_entregable",
    version = "1.0",
    descripcion = "",
    author = "Stefano",
    author_email = "stefanluigi15@gmail.com",
    packages = ["paquete1"]
)
