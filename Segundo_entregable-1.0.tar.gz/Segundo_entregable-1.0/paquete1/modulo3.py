class Cliente:
    def __init__(self, nombre, correo, edad, gustos):
        self.nombre = nombre
        self.correo = correo
        self.edad = edad
        self.gustos = gustos

    def IngresoCliente(self):
        return f"Se ingresó en el sistema al cliente {self.nombre}"


class Comprar(Cliente):

    def __init__(self, nombre, correo, edad, gustos, producto, tienda):
        super().__init__(nombre, correo, edad, gustos)
        self.producto = producto
        self.tienda = tienda

    def compra(self):
        print(f"El cliente compro: {self.producto} en la tienda: {self.tienda}"

# estu = Comprar("Stefano", "stefanoluigi15@gmail.com", 23, ["Tecnologia", "Camisetas"], "Laptop", "Walmart")
#
# estu.compra()
