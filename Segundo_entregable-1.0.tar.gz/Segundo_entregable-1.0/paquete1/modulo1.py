
# def __init__(self, producto, tienda) -> None:
#     self.producto = producto
#     self.tienda = tienda
#
# def __str__(self):
#     texto = f"El cliente compro: {self.producto} en la tienda: {self.tienda}"
#     return texto.format(self.producto, self.tienda)

def compra(producto, tienda):
    # self.producto = producto
    # self.tienda = tienda
    return f"El cliente compro: {producto} en la tienda: {tienda}"

