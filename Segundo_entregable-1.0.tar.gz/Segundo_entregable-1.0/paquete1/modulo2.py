def compra(producto, local):

